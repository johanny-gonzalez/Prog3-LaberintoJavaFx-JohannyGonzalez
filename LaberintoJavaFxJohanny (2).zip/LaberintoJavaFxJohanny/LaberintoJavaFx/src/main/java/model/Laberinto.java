package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Laberinto {
    private final int filas;
    private final int columnas;
    private int[][] mapa;
    private final Random random = new Random();

    public Laberinto(int filas, int columnas) {
        this.filas = filas % 2 == 0 ? filas + 1 : filas;
        this.columnas = columnas % 2 == 0 ? columnas + 1 : columnas;
        generar();
    }

    public void generar() {
        mapa = new int[filas][columnas];

        for (int f = 0; f < filas; f++)
            for (int c = 0; c < columnas; c++)
                mapa[f][c] = 1;

        mapa[1][1] = 0;
        generarDFS(1, 1);

        // Entrada y salida
        mapa[1][0] = 0;
        mapa[filas - 2][columnas - 1] = 0;
    }

    private void generarDFS(int fila, int columna) {
        List<int[]> direcciones = new ArrayList<>();
        direcciones.add(new int[]{-2, 0});
        direcciones.add(new int[]{2, 0});
        direcciones.add(new int[]{0, -2});
        direcciones.add(new int[]{0, 2});
        Collections.shuffle(direcciones, random);

        for (int[] d : direcciones) {
            int nf = fila + d[0];
            int nc = columna + d[1];

            if (esValidoGeneracion(nf, nc)) {
                mapa[fila + d[0] / 2][columna + d[1] / 2] = 0;
                mapa[nf][nc] = 0;
                generarDFS(nf, nc);
            }
        }
    }

    private boolean esValidoGeneracion(int fila, int columna) {
        return fila > 0 && fila < filas - 1
                && columna > 0 && columna < columnas - 1
                && mapa[fila][columna] == 1;
    }

    public boolean puedeMoverse(int fila, int columna) {
        return fila >= 0 && fila < filas
                && columna >= 0 && columna < columnas
                && mapa[fila][columna] == 0;
    }

    public boolean esSalida(int fila, int columna) {
        return fila == filas - 2 && columna == columnas - 1;
    }

    public int getFilas() { return filas; }
    public int getColumnas() { return columnas; }
    public int[][] getMapa() { return mapa; }
}
