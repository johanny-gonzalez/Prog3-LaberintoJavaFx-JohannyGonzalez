package model;

public class Jugador {
    private int fila;
    private int columna;

    public Jugador(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
    }

    public int getFila() { return fila; }
    public int getColumna() { return columna; }

    public void mover(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
    }
}
