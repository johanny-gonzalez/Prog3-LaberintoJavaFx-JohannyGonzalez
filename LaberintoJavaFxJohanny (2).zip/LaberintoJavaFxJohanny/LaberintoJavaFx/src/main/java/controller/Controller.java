package controller;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import model.Jugador;
import model.Laberinto;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    @FXML private Canvas canvas;
    @FXML private Label tiempoLabel, nivelLabel, movimientosLabel, estadoLabel;
    @FXML private ComboBox<String> nivelCombo;
    @FXML private Button nuevoButton, pistaButton, musicaButton;
    @FXML private StackPane canvasContainer;
    @FXML private BorderPane root;

    private Laberinto laberinto;
    private Jugador jugador;
    private GraphicsContext gc;
    private AnimationTimer timer;
    private long tiempoInicio, tiempoRestante;
    private boolean juegoActivo, mostrarPista, musicaActiva = true, aviso30;
    private int movimientos, tiempoMaximo;
    private String nivelActual;
    private final List<int[]> caminoPista = new ArrayList<>();

    private MediaPlayer musica, movimientoSonido, victoriaSonido;

    @FXML
    public void initialize() {
        gc = canvas.getGraphicsContext2D();

        nivelCombo.getItems().addAll("🟢 Fácil", "🟡 Medio", "🔴 Difícil");
        nivelCombo.setValue("🟢 Fácil");

        nuevoButton.setOnAction(e -> iniciarJuego());
        pistaButton.setOnAction(e -> mostrarPista());
        musicaButton.setOnAction(e -> alternarMusica());
        nivelCombo.setOnAction(e -> iniciarJuego());

        canvas.addEventFilter(KeyEvent.KEY_PRESSED, this::manejarTecla);
        root.setFocusTraversable(true);
        root.addEventFilter(KeyEvent.KEY_PRESSED, this::manejarTecla);
        canvas.widthProperty().addListener((o,a,b) -> dibujar());
        canvas.heightProperty().addListener((o,a,b) -> dibujar());

        cargarAudio();
        iniciarJuego();
    }

    private void cargarAudio() {
        try {
            URL musicaUrl = getClass().getResource("/sounds/balada.wav");
            if (musicaUrl != null) {
                musica = new MediaPlayer(new Media(musicaUrl.toExternalForm()));
                musica.setCycleCount(MediaPlayer.INDEFINITE);
                musica.setVolume(0.22);
                musica.play();
            }

            URL movUrl = getClass().getResource("/sounds/movimiento.wav");
            if (movUrl != null) {
                movimientoSonido = new MediaPlayer(new Media(movUrl.toExternalForm()));
                movimientoSonido.setVolume(0.25);
            }

            URL vicUrl = getClass().getResource("/sounds/victoria.wav");
            if (vicUrl != null) {
                victoriaSonido = new MediaPlayer(new Media(vicUrl.toExternalForm()));
                victoriaSonido.setVolume(0.65);
            }
        } catch (Exception e) {
            System.out.println("Audio no disponible: " + e.getMessage());
        }
    }

    private void iniciarJuego() {
        detenerCronometro();

        nivelActual = nivelCombo.getValue();
        int tamano;

        if (nivelActual == null || nivelActual.contains("Fácil")) {
            tamano = 15;
            tiempoMaximo = 180;
        } else if (nivelActual.contains("Medio")) {
            tamano = 21;
            tiempoMaximo = 150;
        } else {
            tamano = 27;
            tiempoMaximo = 120;
        }

        laberinto = new Laberinto(tamano, tamano);
        jugador = new Jugador(1, 1);
        movimientos = 0;
        tiempoRestante = tiempoMaximo;
        juegoActivo = true;
        mostrarPista = false;
        aviso30 = false;
        caminoPista.clear();

        nivelLabel.setText("Nivel: " + nivelActual);
        movimientosLabel.setText("Movimientos: 0");
        estadoLabel.setText("✨ ¡Encuentra la salida!");
        tiempoLabel.setText(formatearTiempo(tiempoMaximo));

        actualizarTema();
        dibujar();
        javafx.application.Platform.runLater(() -> canvas.requestFocus());
        iniciarCronometro();
    }

    private void actualizarTema() {
        String clase = nivelActual.contains("Fácil") ? "nivel-facil"
                : nivelActual.contains("Medio") ? "nivel-medio" : "nivel-dificil";

        canvasContainer.getStyleClass().removeAll(
                "nivel-facil", "nivel-medio", "nivel-dificil"
        );
        canvasContainer.getStyleClass().add(clase);

        nivelLabel.getStyleClass().removeAll(
                "texto-facil", "texto-medio", "texto-dificil"
        );
        nivelLabel.getStyleClass().add(
                nivelActual.contains("Fácil") ? "texto-facil"
                        : nivelActual.contains("Medio") ? "texto-medio"
                        : "texto-dificil"
        );
    }

    private void manejarTecla(KeyEvent e) {
        if (!juegoActivo) return;

        int f = jugador.getFila();
        int c = jugador.getColumna();

        switch (e.getCode()) {
            case UP, W -> f--;
            case DOWN, S -> f++;
            case LEFT, A -> c--;
            case RIGHT, D -> c++;
            default -> { return; }
        }

        moverJugador(f, c);
        e.consume();
    }

    private void moverJugador(int f, int c) {
        if (!laberinto.puedeMoverse(f, c)) {
            estadoLabel.setText("🧱 ¡Hay una pared!");
            return;
        }

        jugador.mover(f, c);
        movimientos++;
        movimientosLabel.setText("Movimientos: " + movimientos);
        estadoLabel.setText("💫 ¡Sigue avanzando!");

        reproducir(movimientoSonido);
        dibujar();

        if (laberinto.esSalida(f, c)) ganar();
    }

    private void iniciarCronometro() {
        tiempoInicio = System.nanoTime();

        timer = new AnimationTimer() {
            @Override
            public void handle(long ahora) {
                long transcurrido = (ahora - tiempoInicio) / 1_000_000_000L;
                long restante = tiempoMaximo - transcurrido;

                if (restante <= 0) {
                    tiempoRestante = 0;
                    tiempoLabel.setText("00:00");
                    perder();
                    return;
                }

                tiempoRestante = restante;
                tiempoLabel.setText(formatearTiempo(restante));

                if (restante <= 30 && !aviso30) {
                    aviso30 = true;
                    estadoLabel.setText("⚠️ ¡Solo quedan 30 segundos!");
                }
            }
        };

        timer.start();
    }

    private void detenerCronometro() {
        if (timer != null) {
            timer.stop();
            timer = null;
        }
    }

    private void ganar() {
        if (!juegoActivo) return;

        juegoActivo = false;
        detenerCronometro();
        reproducir(victoriaSonido);

        long usado = tiempoMaximo - tiempoRestante;

        estadoLabel.setText("🏆 ¡VICTORIA! ¡SALIDA ENCONTRADA!");

        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("🏆 ¡Victoria!");
        a.setHeaderText("🎉 ¡Laberinto completado!");
        a.setContentText(
                "Nivel: " + nivelActual +
                "\nTiempo: " + formatearTiempo(usado) +
                "\nMovimientos: " + movimientos +
                "\n\n¡Excelente trabajo!"
        );
        a.showAndWait();
    }

    private void perder() {
        if (!juegoActivo) return;

        juegoActivo = false;
        detenerCronometro();

        estadoLabel.setText("⏰ ¡Se acabó el tiempo!");

        Alert a = new Alert(Alert.AlertType.WARNING);
        a.setTitle("⏰ Tiempo agotado");
        a.setHeaderText("¡El laberinto te ganó esta vez!");
        a.setContentText(
                "No encontraste la salida.\n" +
                "¡Pulsa Nuevo Laberinto para intentarlo!"
        );
        a.showAndWait();
    }

    private String formatearTiempo(long s) {
        return String.format("%02d:%02d", s / 60, s % 60);
    }

    private void alternarMusica() {
        musicaActiva = !musicaActiva;

        if (musica != null) {
            if (musicaActiva) {
                musica.play();
                musicaButton.setText("🔊 Música: ON");
            } else {
                musica.pause();
                musicaButton.setText("🔇 Música: OFF");
            }
        }
    }

    private void reproducir(MediaPlayer sonido) {
        if (sonido != null) {
            sonido.stop();
            sonido.play();
        }
    }

    private void mostrarPista() {
        if (!juegoActivo) return;

        caminoPista.clear();
        encontrarCamino();
        mostrarPista = true;
        dibujar();

        estadoLabel.setText("💡 Pista activada: sigue los puntos dorados");
    }

    private void encontrarCamino() {
        boolean[][] visitado =
                new boolean[laberinto.getFilas()][laberinto.getColumnas()];

        buscarCamino(
                jugador.getFila(),
                jugador.getColumna(),
                laberinto.getFilas() - 2,
                laberinto.getColumnas() - 1,
                visitado,
                new ArrayList<>()
        );
    }

    private boolean buscarCamino(
            int f, int c, int sf, int sc,
            boolean[][] visitado, List<int[]> actual) {

        if (!laberinto.puedeMoverse(f, c) || visitado[f][c])
            return false;

        visitado[f][c] = true;
        actual.add(new int[]{f, c});

        if (f == sf && c == sc) {
            caminoPista.clear();
            caminoPista.addAll(actual);
            return true;
        }

        int[][] dirs = {
                {-1,0}, {1,0}, {0,-1}, {0,1}
        };

        for (int[] d : dirs) {
            if (buscarCamino(
                    f + d[0], c + d[1],
                    sf, sc, visitado, actual)) {
                return true;
            }
        }

        actual.remove(actual.size() - 1);
        return false;
    }

    private void dibujar() {
        if (laberinto == null) return;

        double w = canvas.getWidth();
        double h = canvas.getHeight();

        gc.setFill(Color.web("#08111F"));
        gc.fillRect(0, 0, w, h);

        int filas = laberinto.getFilas();
        int cols = laberinto.getColumnas();

        double celda = Math.min(w / cols, h / filas);
        double ix = (w - celda * cols) / 2;
        double iy = (h - celda * filas) / 2;

        Color pared;
        Color camino;

        if (nivelActual.contains("Fácil")) {
            pared = Color.web("#064E3B");
            camino = Color.web("#ECFDF5");
        } else if (nivelActual.contains("Medio")) {
            pared = Color.web("#78350F");
            camino = Color.web("#FFFBEB");
        } else {
            pared = Color.web("#581C87");
            camino = Color.web("#FDF4FF");
        }

        int[][] mapa = laberinto.getMapa();

        for (int f = 0; f < filas; f++) {
            for (int c = 0; c < cols; c++) {
                double x = ix + c * celda;
                double y = iy + f * celda;

                gc.setFill(mapa[f][c] == 1 ? pared : camino);
                gc.fillRoundRect(
                        x + 1, y + 1,
                        celda - 2, celda - 2,
                        4, 4
                );
            }
        }

        if (mostrarPista) {
            gc.setFill(Color.web("#FFD700"));

            for (int[] p : caminoPista) {
                double x = ix + p[1] * celda;
                double y = iy + p[0] * celda;

                gc.fillOval(
                        x + celda * .32,
                        y + celda * .32,
                        celda * .36,
                        celda * .36
                );
            }
        }

        // Entrada
        gc.setFill(Color.web("#22C55E"));
        gc.fillRoundRect(
                ix + 2, iy + celda + 2,
                celda - 4, celda - 4, 8, 8
        );

        gc.setFill(Color.WHITE);
        gc.fillText(
                "E",
                ix + celda * .38,
                iy + celda * 1.65
        );

        // Salida
        int sf = filas - 2;
        int sc = cols - 1;

        double sx = ix + sc * celda;
        double sy = iy + sf * celda;

        gc.setFill(Color.web("#EF4444"));
        gc.fillRoundRect(
                sx + 2, sy + 2,
                celda - 4, celda - 4,
                8, 8
        );

        gc.setFill(Color.WHITE);
        gc.fillText(
                "S",
                sx + celda * .38,
                sy + celda * .65
        );

        // Jugador
        double jx = ix + jugador.getColumna() * celda;
        double jy = iy + jugador.getFila() * celda;

        gc.setFill(Color.web("#3B82F6"));
        gc.fillOval(
                jx + celda * .12,
                jy + celda * .12,
                celda * .76,
                celda * .76
        );

        gc.setFill(Color.WHITE);
        gc.fillOval(
                jx + celda * .29,
                jy + celda * .29,
                celda * .12,
                celda * .12
        );

        gc.fillOval(
                jx + celda * .59,
                jy + celda * .29,
                celda * .12,
                celda * .12
        );
    }
}
