# 🧩 Proyecto Final — Laberinto

## Estudiante
Johanny Alt. González De Jesús

## Descripción
Juego de laberinto desarrollado en Java 21, JavaFX, FXML y CSS. El laberinto se genera aleatoriamente mediante DFS recursivo y siempre existe un camino desde la entrada hasta la salida.

## Tres niveles
- 🟢 Fácil: 15 x 15 — 180 segundos.
- 🟡 Medio: 21 x 21 — 150 segundos.
- 🔴 Difícil: 27 x 27 — 120 segundos.

Cada nivel tiene una apariencia de color diferente y aumenta el reto mediante el tamaño y el tiempo disponible.

## Funciones
- Generación aleatoria con DFS recursivo.
- Canvas para dibujar el laberinto.
- Movimiento con flechas y WASD.
- Colisiones con paredes.
- Entrada y salida diferenciadas.
- Cronómetro y límite de tiempo.
- Contador de movimientos.
- Pista con camino dorado.
- Nuevo laberinto.
- Música de fondo tipo balada instrumental.
- Botón para activar/desactivar música.
- Efecto de movimiento.
- Sonido de victoria.
- Pantalla de victoria y derrota.

## Ejecución
Requiere JDK 21 y Maven.

En la carpeta raíz:

```bash
mvn clean javafx:run
```

## Audio
Los archivos incluidos son sonidos instrumentales generados para el proyecto, sin utilizar una canción comercial. JavaFX MediaPlayer los reproduce desde `src/main/resources/sounds`.
